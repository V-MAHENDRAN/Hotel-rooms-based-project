import java.util.*;
public class Main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int size=sc.nextInt();
        int[] a=new int[size];
        int i,j,rev=0;
        int booked=1;
        int free=0;
        for (j=0;j<n;j++){
        for(i=0;i<size;i++){
            a[i]=sc.nextInt();
        
        while(a[i]!=0){
            int rem=a[i]%10;
             rev=(rev*10)+rem;
            a[i]=a[i]/10;
        }
        }
        }for(j=0;j<n;j++){
        for(i=0;i<size;i++){
        int booking=rev%10;
        if(booking==booked){
            free++;
        }
        else{
            System.out.println("Room is free");
        }
           
        }
         System.out.println("Collected coin for room:"+" "+free);
        }
    
        
    }
}